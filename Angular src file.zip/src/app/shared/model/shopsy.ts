export class Shopsy{
    id!:number;
    price!:number;
    name!:string;
    favorite:boolean=false;
    imageUrl!:string;
    fabric!:string;
    origin?:string[];
}